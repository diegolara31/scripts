param (
    [switch]$InstallBrave,
    [switch]$InstallFirefox
)

# Function to update Winget
function Update-Winget {
    Write-Host "Updating Winget"
    Start-Process -FilePath "powershell" -ArgumentList '-NoProfile', '-ExecutionPolicy Bypass', '-Command', '.\wingetUpdate.ps1' -Verb RunAs -Wait
}

# Function to install Brave
function Install-Brave {
    Write-Host "Installing Brave Browser"
    Start-Process -FilePath "winget" -ArgumentList 'install Brave.Brave --source winget --scope machine --silent --accept-source-agreements --accept-package-agreements' -Verb RunAs -Wait

    Write-Host "Configuring Brave"
    $braveSourcePath = "BraveSoftware"
    $braveTargetProgramFiles = "$env:ProgramFiles\BraveSoftware"
    $braveTargetLocalAppData = "$env:LOCALAPPDATA\BraveSoftware"
    robocopy $braveSourcePath $braveTargetProgramFiles /E /IM /IT /NP
    robocopy $braveSourcePath $braveTargetLocalAppData /E /IM /IT /NP
}

# Function to install Firefox
function Install-Firefox {
    Write-Host "Installing Firefox Browser"
    Start-Process -FilePath "winget" -ArgumentList 'install Mozilla.Firefox --source winget --scope machine --silent --accept-source-agreements --accept-package-agreements' -Verb RunAs -Wait

    # Configure Firefox settings
    Write-Host "Configuring Firefox"

    # Retrieve user SIDs
    $userSids = Get-ChildItem "HKU" | Where-Object { $_.PSChildName -match 'S-\d-\d+(-\d+)*' } | ForEach-Object { $_.PSChildName }

    foreach ($sid in $userSids) {
        # Check if the Volatile Environment key exists
        $volEnvKeyExists = Test-Path "HKU\$sid\Volatile Environment"

        if ($volEnvKeyExists) {
            # Set Firefox policies
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "DisableTelemetry" -Value 1 -Type DWord -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "DisablePocket" -Value 1 -Type DWord -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "CaptivePortal" -Value 0 -Type DWord -ErrorAction SilentlyContinue
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "DisableFirefoxStudies" -Value 1 -Type DWord -ErrorAction SilentlyContinue
            
            # Set ExtensionSettings
            $extensionSettings = '{"uBlock0@raymondhill.net": {"installation_mode": "force_installed", "install_url": "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"}}'
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "ExtensionSettings" -Value $extensionSettings -Type MultiString -ErrorAction SilentlyContinue
            
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "DisableDefaultBrowserAgent" -Value 1 -Type DWord -ErrorAction SilentlyContinue
            
            $preferences = '{"network.cookie.sameSite.laxByDefault":{"Value":true,"Status":"user"},"network.cookie.sameSite.noneRequiresSecure":{"Value":true,"Status":"user"},"network.cookie.sameSite.schemeful":{"Value":true,"Status":"user"},"browser.contentblocking.category":{"Value":"strict","Status":"user"},"browser.newtabpage.activity-stream.showSponsored":{"Value":false,"Status":"user"},"browser.newtabpage.activity-stream.showSponsoredTopSites":{"Value":false,"Status":"user"}}'
            Set-ItemProperty -Path "HKU\$sid\Software\Policies\Mozilla\Firefox" -Name "Preferences" -Value $preferences -Type MultiString -ErrorAction SilentlyContinue
            
        }
    }
}

# Main script execution
Update-Winget

if ($InstallBrave) {
    Install-Brave
}

if ($InstallFirefox) {
    Install-Firefox
}
