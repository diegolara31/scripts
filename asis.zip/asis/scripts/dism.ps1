function Update-Feature {
    param(
        [string]$featureName,
        [bool]$enableFeature
    )
    
    # Registry path for optional feature tracking
    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Notifications\OptionalFeatures"
    
    # Get current feature state from registry
    $regKey = Get-ItemProperty -Path "$regPath\$featureName" -ErrorAction SilentlyContinue
    
    # Determine the command based on whether enabling or disabling the feature
    $dismCmd = if ($enableFeature) { "Enable" } else { "Disable" }

    # If the feature is not found in registry, or if its state differs from the desired state, change it
    if (-not $regKey -or ($regKey.Selection -eq 0 -and $enableFeature) -or ($regKey.Selection -eq 1 -and -not $enableFeature)) {
        Write-Host "$dismCmd feature: $featureName"
        
        # Use the appropriate PowerShell command to enable/disable the feature
        try {
            if ($enableFeature) {
                Enable-WindowsOptionalFeature -Online -FeatureName $featureName -NoRestart -All -ErrorAction Stop
            } else {
                Disable-WindowsOptionalFeature -Online -FeatureName $featureName -NoRestart -ErrorAction Stop
            }
            Write-Host "$featureName feature updated successfully."
        } catch {
            Write-Warning "Failed to $dismCmd $featureName: $_"
        }
    } else {
        Write-Host "No changes needed for $featureName."
    }
}

# List of features and their desired states
$features = @(
    @{ Name = "DirectPlay"; Bool = $true },
    @{ Name = "LegacyComponents"; Bool = $true },
    @{ Name = "MicrosoftWindowsPowerShellV2"; Bool = $false },
    @{ Name = "MicrosoftWindowsPowerShellV2Root"; Bool = $false },
    @{ Name = "MSRDC-Infrastructure"; Bool = $false },
    @{ Name = "Printing-Foundation-Features"; Bool = $false },
    @{ Name = "Printing-Foundation-InternetPrinting-Client"; Bool = $false },
    @{ Name = "WorkFolders-Client"; Bool = $false }
    # @{ Name = "SmbDirect"; Bool = $false }  # Optional
)

# Loop through each feature and apply the corresponding update
foreach ($feature in $features) {
    Update-Feature -featureName $feature.Name -enableFeature $feature.Bool
}
