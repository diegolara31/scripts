# Disable Microsoft Copilot
function Disable-MicrosoftCopilot {
    Write-Host "Disabling Microsoft Copilot..."
    
    # Registry paths and values to disable Copilot
    $registryChanges = @(
        @{
            Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot"
            Name = "TurnOffWindowsCopilot"
            Type = "DWord"
            Value = 1
        },
        @{
            Path = "HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot"
            Name = "TurnOffWindowsCopilot"
            Type = "DWord"
            Value = 1
        },
        @{
            Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
            Name = "ShowCopilotButton"
            Type = "DWord"
            Value = 0
        }
    )
    
    # Apply registry changes
    foreach ($reg in $registryChanges) {
        if (-not (Test-Path $reg.Path)) {
            New-Item -Path $reg.Path -Force | Out-Null
        }
        Set-ItemProperty -Path $reg.Path -Name $reg.Name -Value $reg.Value -Type $reg.Type -Force
        Write-Host "Updated registry at $($reg.Path)\$($reg.Name) to $($reg.Value)"
    }

    # Use DISM to remove Copilot package
    try {
        Write-Host "Removing Microsoft Copilot package..."
        dism /online /remove-package /package-name:Microsoft.Windows.Copilot
    } catch {
        Write-Warning "Failed to remove Copilot package: $_"
    }
    
    Write-Host "Microsoft Copilot disabled successfully."
}