# Asegúrate de que el script se ejecute con privilegios elevados
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Este script debe ejecutarse como administrador."
    exit
}

function Remove-AppxPackage {
    param (
        [string]$packageName
    )
    try {
        Get-AppxPackage -Name $packageName | Remove-AppxPackage -ErrorAction Stop
        Write-Host "El paquete $packageName ha sido eliminado."
    } catch {
        Write-Host "No se pudo eliminar el paquete $packageName. Error: $_"
    }
}

# Lista de paquetes a eliminar
$packagesToRemove = @(
    '*microsoft.microsoftedge.stable*',
    '*Microsoft.MicrosoftEdge*',
    '*Microsoft.MicrosoftEdgeDevToolsClient*',
    '*OneDrive*',
    '*Spotify*',
    '*SecureAssessmentBrowser*',
    '*PeopleExperienceHost*',
    '*Microsoft.Windows.Photos*',
    '*Microsoft.WindowsCamera*',
    '*MicrosoftWindows.Client.WebExperience*',
    '*Microsoft.WindowsAlarms*',
    '*Microsoft.WindowsMaps*',
    '*Microsoft.MicrosoftStickyNotes*',
    '*windowscommunicationsapps*',
    '*Microsoft.People*',
    '*Microsoft.BingNews*',
    '*BingSearch*',
    '*Microsoft.BingWeather*',
    '*Microsoft.MicrosoftSolitaireCollection*',
    '*Microsoft.WindowsFeedbackHub*',
    '*Microsoft.GetHelp*',
    '*Microsoft.Getstarted*',
    '*Microsoft.Todos*',
    '*Microsoft.PowerAutomateDesktop*',
    '*Microsoft.549981C3F5F10*',
    '*MicrosoftCorporationII.QuickAssist*',
    '*MicrosoftCorporationII.MicrosoftFamily*',
    '*Microsoft.ZuneMusic*',
    '*Microsoft.ZuneVideo*',
    '*Microsoft.WindowsSoundRecorder*',
    '*Clipchamp.Clipchamp*',
    '*Microsoft.Whiteboard*',
    '*microsoft.microsoftskydrive*',
    '*Microsoft.MicrosoftTeamsforSurfaceHub*',
    '*MicrosoftCorporationII.MailforSurfaceHub*',
    '*Microsoft.MicrosoftPowerBIForWindows*',
    '*Microsoft.SkypeApp*',
    '*Microsoft.MicrosoftOfficeHub*',
    '*Microsoft.Office.Excel*',
    '*Microsoft.Office.PowerPoint*',
    '*Microsoft.Office.Word*',
    '*Microsoft.Office.OneNote*',
    '*OutlookForWindows*',
    '*OutlookPWA*',
    '*Microsoft.Microsoft3DViewer*',
    '*Microsoft.Advertising*',
    '*MixedReality.Portal*',
    '*Microsoft.MSPaint*',
    '*MicrosoftTeams*',
    '*MSTeams*',
    '*DevHome*',
    '*Flipgrid*',
    '*Microsoft.Xbox*',
    '*Microsoft.GamingApp*',
    '*Microsoft.XboxApp*',
    '*Microsoft.YourPhone*',
    '*MicrosoftWindows.CrossDevice*',
    '*MicrosoftWindows.Client.AIX*'
)

# Remover paquetes
foreach ($package in $packagesToRemove) {
    Remove-AppxPackage -packageName $package
}

# Remover paquetes usando comandos PowerShell adicionales
try {
    Get-AppxPackage MicrosoftWindows.Client.WebExperience | Remove-AppxPackage -ErrorAction Stop
    Write-Host "Web Experience Package eliminado."
} catch {
    Write-Host "Error al eliminar Web Experience Package: $_"
}

try {
    Get-AppxPackage *windowscommunicationsapps* | Remove-AppxPackage -ErrorAction Stop
    Write-Host "Windows Communications Apps Package eliminado."
} catch {
    Write-Host "Error al eliminar Windows Communications Apps Package: $_"
}

# Cierra Microsoft Teams si está en ejecución
Stop-Process -Name "*teams*" -ErrorAction SilentlyContinue

Write-Host "El proceso de eliminación de paquetes ha finalizado."
