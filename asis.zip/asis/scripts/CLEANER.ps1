# Set to silently continue on errors
$ErrorActionPreference = 'SilentlyContinue'

# Informing the user that Disk Cleanup is running with custom settings
Write-Host "Using Disk Cleanup with custom configuration"

# Define a dictionary containing cache items and their respective cleanup settings (2 = Clean)
$volumeCache = @{
    "Active Setup Temp Folders"      = 2
    "BranchCache"                    = 2
    "Delivery Optimization Files"    = 2
    "Device Driver Packages"         = 2
    "Downloaded Program Files"       = 2
    "Internet Cache Files"           = 2
    "Language Pack"                  = 2
    "Offline Pages Files"            = 2
    "Old ChkDsk Files"               = 2
    "Setup Log Files"                = 2
    "System error memory dump files" = 2
    "System error minidump files"    = 2
    "Temporary Setup Files"          = 2
    "Temporary Sync Files"           = 2
    "Update Cleanup"                 = 2
    "Upgrade Discarded Files"        = 2
    "User file versions"             = 2
    "Windows Defender"               = 2
    "Windows Error Reporting Files"  = 2
    "Windows Reset Log Files"        = 2
    "Windows Upgrade Log Files"      = 2
}

# Registry path for volume caches
$registryPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"

# Loop through each cache item and set the corresponding registry value for cleanup
foreach ($item in $volumeCache.GetEnumerator()) {
    $keyPath = Join-Path $registryPath $item.Key
    if (Test-Path $keyPath) {
        # Set 'StateFlags1337' registry value to 2 for each cache item
        New-ItemProperty -Path $keyPath -Name StateFlags1337 -Value $item.Value -PropertyType DWord | Out-Null
    }
}

# Run Disk Cleanup with the custom profile (ID 1337)
Start-Process -FilePath "$env:SystemRoot\system32\cleanmgr.exe" -ArgumentList "/sagerun:1337" -Wait:$false

# Informing the user that event logs are being cleaned
Write-Host "Cleaning up Event Logs"
# Clear all event logs
Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }

# Disable Windows Reserved Storage to save space
Write-Host "Disabling Reserved Storage"
Set-WindowsReservedStorageState -State Disabled

# Stop unnecessary services to free up resources
Stop-Service -Name "bits" -Force | Out-Null
Stop-Service -Name "appidsvc" -Force | Out-Null
Stop-Service -Name "dps" -Force | Out-Null
Stop-Service -Name "wuauserv" -Force | Out-Null
Stop-Service -Name "cryptsvc" -Force | Out-Null

# Informing the user that leftover files are being cleaned
Write-Host "Cleaning up leftovers"

# List of directories to be removed for cleanup
$foldersToRemove = @(
    "CbsTemp",
    "Logs",
    "SoftwareDistribution",
    "System32\LogFiles",
    "System32\LogFiles\WMI",
    "System32\SleepStudy",
    "System32\sru",
    "System32\WDI\LogFiles",
    "System32\winevt\Logs",
    "SystemTemp",
    "Temp"
    # "WinSxS\Backup"  # Commented out folder for optional removal
    # "Panther",       # Commented out folder for optional removal
    # "Prefetch"       # Commented out folder for optional removal
)

# Loop through each folder and remove its contents if it exists
foreach ($folderName in $foldersToRemove) {
    $folderPath = Join-Path $env:SystemRoot $folderName
    if (Test-Path $folderPath) {
        Remove-Item -Path "$folderPath\*" -Force -Recurse | Out-Null
    }
}

# Clean up log files
Get-ChildItem -Path "$env:SystemRoot" -Filter *.log -File -Recurse -Force | Remove-Item -Recurse -Force | Out-Null

# Clean up files from the system's temporary folder (except for 'AME')
Write-Host "Cleaning up %TEMP%"
Get-ChildItem -Path "$env:TEMP" -Exclude "AME" | Remove-Item -Recurse -Force

# Start the scheduled Disk Cleanup task silently
Start-ScheduledTask -TaskPath "\Microsoft\Windows\DiskCleanup\" -TaskName "SilentCleanup"

# Edge update cleanup (if the path exists)
$edgeUpdatePath = ${env:ProgramFiles(x86)} + "\Microsoft\EdgeUpdate\Download"
if (Test-Path -Path $edgeUpdatePath) {
    Remove-Item -Path $edgeUpdatePath -Force -Recurse | Out-Null
}
